plot.PCLasso <-
function(x, norm = TRUE, ...){
    plot(x$fit, norm = norm, ...)
}
